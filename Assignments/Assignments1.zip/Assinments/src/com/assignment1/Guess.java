package com.assignment1;
import java.util.Scanner;
public class Guess {

	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		int number =1+(int)(100*Math.random());
		//System.out.println(number);
		int k=5;
		int i,guess;
		System.out.println("The numbe is choosen between 1 to 100, guess the numbe within 5 trial");
		for(i=0;i<k;i++) {
			System.out.println("Guess the number");
			guess =scn.nextInt();
			if(number==guess) {
				System.out.println("Congrats your guess was correct");
			}
			else if(guess>number&& i!=k-1) {
				System.out.println("the number is less than "+guess);
			}
			else if(guess<number&& i!=k-1) {
				System.out.println("the number is greater than "+guess);
			}
		}
		if(i==k) {
			System.out.println("You have exausted "+k+" trials");
			System.out.println("the number is: "+number);
		}
	}

}
