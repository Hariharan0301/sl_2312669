package com.assignment1;

public class Advise {

	public static void main(String[] args) {
		
	}

}
