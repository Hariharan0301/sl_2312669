package com.assignment1;

import java.util.Scanner;

public class Display {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter start and end");
		int start=scn.nextInt();
		int end =scn.nextInt();
		while(start<=end) {
			System.out.println(start);
			start++;
		}
	}

}
