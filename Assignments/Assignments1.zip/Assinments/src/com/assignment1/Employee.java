package com.assignment1;

import java.util.Scanner;

public class Employee {
	public static void main(String[] args) {
		Employee employee=new Employee();
		double salary= employee.getInfo();
		System.out.println(salary);
		
	}
	public double getInfo() {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Salary and working Hours");
		double salary=scn.nextDouble();
		int hour=scn.nextInt();
		Employee employee=new Employee();
		salary=employee.addSal(salary);
		salary=employee.addHour(salary,hour);
		
		return salary;
	}
	public double addSal(double sal) {
		if(sal<1500) {
			sal=sal+1000;
		}
		return sal;
	}
	public double addHour(double sal, int hour) {
		if(hour>8) {
			sal=sal+500;
		}
		return sal;
	}

}
