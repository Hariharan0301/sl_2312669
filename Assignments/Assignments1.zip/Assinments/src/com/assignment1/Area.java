package com.assignment1;
public class Area {
	public static void main(String[] args) {
		Area area= new Area(2,6,7);
		System.out.println(area.calculateArea());
		System.out.println(area.calculatePerimeter());
	}
		private int a,b,c;
		Area(int a,int b,int c){
			this.a =a;
			this.b=b;
			this.c=c;
		}
		public int getA() {
			return a;
		}
		public void setA(int a) {
			this.a = a;
		}
		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		public int getC() {
			return c;
		}
		public void setC(int c) {
			this.c = c;
		}
		public double calculateArea() {
			int side=(a+b+c)/2;
			return Math.sqrt(side*(side-a)*(side-b)*(side-c));
		}
		public int calculatePerimeter() {
			return a+b+c;
		}
	}


